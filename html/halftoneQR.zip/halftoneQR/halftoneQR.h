#ifndef PROJECT_HALFTONED_QR_H
#define PROJECT_HALFTONED_QR_H

#include <qrencode.h>
#include <FreeImage.h>

void *halftoneQR(void);

#endif //PROJECT_HALFTONED_QR_H
