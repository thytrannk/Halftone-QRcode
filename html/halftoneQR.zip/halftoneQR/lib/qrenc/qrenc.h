#include <qrencode.h>

int writePNG(QRcode *qrcode, const char *outfile);
