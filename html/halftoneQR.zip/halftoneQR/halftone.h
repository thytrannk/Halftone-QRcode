#ifndef PROJECT_HALFTONE_H
#define PROJECT_HALFTONE_H

void floyd();
void dotDiffusion();

#endif //PROJECT_HALFTONE_H
